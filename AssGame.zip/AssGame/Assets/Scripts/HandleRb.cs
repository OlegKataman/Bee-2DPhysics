using UnityEngine;
using UnityEngine.EventSystems;

public class HandleRb : MonoBehaviour, IDragHandler, IBeginDragHandler, IEndDragHandler
{
    private Vector3 _line;
    private Vector3 _endLine;

    [SerializeField] private Rigidbody2D beeRb;
    [SerializeField] private Rigidbody2D stingRb;
    
    [SerializeField] private Transform circle;

    public void OnDrag(PointerEventData eventData)
    {
        _line = transform.position;
        _endLine = eventData.pointerCurrentRaycast.worldPosition;
        
        circle.position = _endLine;

        beeRb.gravityScale = 0.05f;
        beeRb.centerOfMass = _endLine;

        var direction = _endLine - _line;
        
        beeRb.AddForce(direction.normalized * 20f, ForceMode2D.Force);
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        
    }
    
    public void OnEndDrag(PointerEventData eventData)
    {
        var direction = _endLine - _line;

        beeRb.centerOfMass = Vector2.zero;
        beeRb.gravityScale = 0;
        
        stingRb.AddForce(direction.normalized * direction.magnitude, ForceMode2D.Impulse);
        
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawLine(_line, _endLine);
    }
}