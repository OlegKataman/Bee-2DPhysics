using UnityEngine;
using UnityEngine.EventSystems;

public class Handle : MonoBehaviour, IDragHandler, IBeginDragHandler, IEndDragHandler
{
    private Vector3 _startPoint;
    private Vector3 _endPoint;
    private Rigidbody2D _rb;

    private void Awake() => _rb = GetComponent<Rigidbody2D>();

    
    public void OnDrag(PointerEventData eventData)
    {
        _startPoint = transform.position;
        _endPoint = eventData.pointerCurrentRaycast.worldPosition;
        
        _rb.gravityScale = 0.05f;

        var direction = _endPoint - _startPoint;
        
        _rb.AddForce(direction.normalized * 2f, ForceMode2D.Force);
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
    }
    
    public void OnEndDrag(PointerEventData eventData)
    {
        var direction = _endPoint - _startPoint;
        
        _rb.gravityScale = 0;
        
        _rb.AddForceAtPosition(direction.normalized * direction.magnitude, this.transform.position, ForceMode2D.Impulse);
        
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawLine(_startPoint, _endPoint);
    }
}