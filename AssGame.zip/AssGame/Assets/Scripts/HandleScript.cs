using System;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.EventSystems;

public class HandleScript : MonoBehaviour, IDragHandler, IBeginDragHandler
{
    [SerializeField] private Vector3 _line;
    [SerializeField] private Vector3 _endLine;
    
    [SerializeField] private Transform point1;
    [SerializeField] private Transform point2;
    
    public void OnDrag(PointerEventData eventData)
    {
        _endLine = eventData.pointerCurrentRaycast.screenPosition;
        point2.transform.position = eventData.pointerCurrentRaycast.worldPosition;

        //Debug.DrawLine(_line,_endLine, Color.red);
        //Debug.DrawLine(point1.position,point2.position, Color.red);
        //Debug.DrawRay(_line, (_line - _endLine).normalized, Color.red);
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        _line = eventData.pointerCurrentRaycast.screenPosition;
        point1.transform.position = eventData.pointerCurrentRaycast.worldPosition;
    }

    //[ExecuteAlways]
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawLine(point1.position,point2.position);
    }
}


/*
        if (Mathf.Abs(eventData.delta.x) > Mathf.Abs(eventData.delta.y))
        {
            if (eventData.delta.x > 0)
                Debug.Log("Right");
            else
                Debug.Log("Left");

            player.position += new Vector3(eventData.delta.x, 0, 0) * 10;
        }
        else
        {
            if (eventData.delta.y > 0)
                Debug.Log("Up");
            else
                Debug.Log("Down");

            player.position += new Vector3(0, eventData.delta.y, 0) * 10;
        }*/